# PIKU 쇼핑몰 — 배포 & 실결제 전환 가이드

## 파일 구성
- `index.html` — 쇼핑몰 (장바구니 + 토스 결제창)
- `success.html` / `fail.html` — 결제 성공/실패 페이지
- `api/confirm.js` — 결제 승인 서버 (Vercel 함수)

---

## 1단계. Vercel에 배포 (무료, 10분)

1. https://vercel.com 가입 (GitHub 계정으로)
2. GitHub에 새 저장소 만들고 이 폴더 파일 전부 업로드
3. Vercel에서 **Add New → Project** → 그 저장소 선택 → Deploy
4. 배포되면 `https://내이름.vercel.app` 주소가 생김

## 2단계. 시크릿 키 등록

1. 토스페이먼츠 개발자센터 → API 키 메뉴
2. **테스트 시크릿 키** (`test_sk_...`) 복사
3. Vercel 프로젝트 → **Settings → Environment Variables**
   - Name: `TOSS_SECRET_KEY`
   - Value: `test_sk_...` 붙여넣기
4. **Redeploy** (Deployments 탭에서 재배포)

→ 여기까지 하면 **테스트 결제가 끝까지 작동**함.
   결제창에서 아무 카드번호나 넣어도 승인되고 돈은 안 빠짐.

## 3단계. 실결제 전환 (가맹점 심사 통과 후)

필요한 것: 사업자등록증 + 통신판매업 신고 → 토스페이먼츠 가맹 심사 신청 → 통과하면 라이브 키 발급됨.

통과 후 바꿀 곳 딱 2군데:
1. `index.html`에서 `TOSS_CLIENT_KEY`를 `live_ck_...`로 교체
2. Vercel 환경변수 `TOSS_SECRET_KEY`를 `live_sk_...`로 교체 후 재배포

## 4단계. 도메인 연결

Vercel 프로젝트 → Settings → Domains → 산 도메인 입력 → 안내대로 DNS 설정.

---

## 상품 수정할 때 주의
`index.html`의 `products` 목록과 `api/confirm.js`의 `PRICES` 표를
**반드시 둘 다 똑같이** 수정할 것. (다르면 결제가 "금액 검증 실패"로 막힘 — 가격 조작 방지 장치임)

## 주문 확인
결제된 주문은 토스페이먼츠 대시보드 → 거래내역에서 확인.
